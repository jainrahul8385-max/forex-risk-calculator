import { ForexCalculator } from "@/components/forex-calculator";
import { TrendingUp } from "lucide-react";

export default function Home() {
  return (
    <main className="min-h-screen bg-background px-4 py-8 md:py-16">
      {/* Background Pattern */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto">
        {/* Branding Header */}
        <header className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-primary/10 rounded-full mb-6">
            <TrendingUp className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium text-primary">
              Forex Trading Tools
            </span>
          </div>
          <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-4 text-balance">
            Position Size Calculator
          </h1>
          <p className="text-muted-foreground max-w-lg mx-auto text-pretty">
            Calculate the optimal lot size for your trades based on your risk tolerance and account size.
          </p>
        </header>

        {/* Calculator */}
        <ForexCalculator />

        {/* Footer */}
        <footer className="mt-16 text-center">
          <p className="text-xs text-muted-foreground">
            Trading forex carries a high level of risk. Only trade with money you can afford to lose.
          </p>
        </footer>
      </div>
    </main>
  );
}
