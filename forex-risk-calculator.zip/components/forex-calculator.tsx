"use client";

import { useState, useCallback } from "react";
import { DollarSign, Percent, TrendingDown, Calculator, Info } from "lucide-react";

type CurrencyPair = {
  name: string;
  pipValue: number;
};

const CURRENCY_PAIRS: CurrencyPair[] = [
  { name: "EUR/USD", pipValue: 10 },
  { name: "GBP/USD", pipValue: 10 },
  { name: "USD/JPY", pipValue: 9.1 },
  { name: "USD/CHF", pipValue: 10.2 },
  { name: "AUD/USD", pipValue: 10 },
  { name: "NZD/USD", pipValue: 10 },
  { name: "USD/CAD", pipValue: 7.5 },
  { name: "EUR/GBP", pipValue: 12.5 },
  { name: "EUR/JPY", pipValue: 9.1 },
  { name: "GBP/JPY", pipValue: 9.1 },
];

export function ForexCalculator() {
  const [accountBalance, setAccountBalance] = useState<string>("10000");
  const [riskPercentage, setRiskPercentage] = useState<string>("2");
  const [stopLossPips, setStopLossPips] = useState<string>("50");
  const [selectedPair, setSelectedPair] = useState<CurrencyPair>(CURRENCY_PAIRS[0]);
  const [isCalculated, setIsCalculated] = useState(false);

  const calculateLotSize = useCallback(() => {
    const balance = parseFloat(accountBalance) || 0;
    const risk = parseFloat(riskPercentage) || 0;
    const stopLoss = parseFloat(stopLossPips) || 0;
    const pipValue = selectedPair.pipValue;

    if (balance <= 0 || risk <= 0 || stopLoss <= 0) {
      return { lotSize: 0, riskAmount: 0, isValid: false };
    }

    const riskAmount = (balance * risk) / 100;
    const lotSize = riskAmount / (stopLoss * pipValue);

    return {
      lotSize: Math.round(lotSize * 100) / 100,
      riskAmount: Math.round(riskAmount * 100) / 100,
      isValid: true,
    };
  }, [accountBalance, riskPercentage, stopLossPips, selectedPair]);

  const result = calculateLotSize();

  const handleCalculate = () => {
    setIsCalculated(true);
  };

  const handleReset = () => {
    setAccountBalance("10000");
    setRiskPercentage("2");
    setStopLossPips("50");
    setSelectedPair(CURRENCY_PAIRS[0]);
    setIsCalculated(false);
  };

  return (
    <div className="w-full max-w-xl mx-auto">
      <div className="bg-card border border-border rounded-2xl p-6 md:p-8 shadow-2xl shadow-primary/5">
        {/* Header */}
        <div className="flex items-center gap-3 mb-8">
          <div className="p-3 bg-primary/10 rounded-xl">
            <Calculator className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h1 className="text-xl md:text-2xl font-bold text-foreground">
              Risk Calculator
            </h1>
            <p className="text-sm text-muted-foreground">
              Calculate your optimal position size
            </p>
          </div>
        </div>

        {/* Currency Pair Selector */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-muted-foreground mb-2">
            Currency Pair
          </label>
          <select
            value={selectedPair.name}
            onChange={(e) => {
              const pair = CURRENCY_PAIRS.find((p) => p.name === e.target.value);
              if (pair) setSelectedPair(pair);
            }}
            className="w-full bg-input border border-border rounded-xl px-4 py-3 text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all appearance-none cursor-pointer"
          >
            {CURRENCY_PAIRS.map((pair) => (
              <option key={pair.name} value={pair.name} className="bg-card">
                {pair.name}
              </option>
            ))}
          </select>
        </div>

        {/* Input Fields */}
        <div className="space-y-5">
          {/* Account Balance */}
          <div>
            <label className="block text-sm font-medium text-muted-foreground mb-2">
              Account Balance
            </label>
            <div className="relative">
              <div className="absolute left-4 top-1/2 -translate-y-1/2">
                <DollarSign className="w-5 h-5 text-muted-foreground" />
              </div>
              <input
                type="number"
                value={accountBalance}
                onChange={(e) => {
                  setAccountBalance(e.target.value);
                  setIsCalculated(false);
                }}
                placeholder="10000"
                min="0"
                className="w-full bg-input border border-border rounded-xl pl-12 pr-4 py-3 text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
              />
            </div>
          </div>

          {/* Risk Percentage */}
          <div>
            <label className="block text-sm font-medium text-muted-foreground mb-2">
              Risk Percentage
            </label>
            <div className="relative">
              <div className="absolute left-4 top-1/2 -translate-y-1/2">
                <Percent className="w-5 h-5 text-muted-foreground" />
              </div>
              <input
                type="number"
                value={riskPercentage}
                onChange={(e) => {
                  setRiskPercentage(e.target.value);
                  setIsCalculated(false);
                }}
                placeholder="2"
                min="0"
                max="100"
                step="0.1"
                className="w-full bg-input border border-border rounded-xl pl-12 pr-4 py-3 text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
              />
            </div>
            <p className="text-xs text-muted-foreground mt-1.5 flex items-center gap-1">
              <Info className="w-3 h-3" />
              Recommended: 1-2% per trade
            </p>
          </div>

          {/* Stop Loss Pips */}
          <div>
            <label className="block text-sm font-medium text-muted-foreground mb-2">
              Stop Loss (Pips)
            </label>
            <div className="relative">
              <div className="absolute left-4 top-1/2 -translate-y-1/2">
                <TrendingDown className="w-5 h-5 text-muted-foreground" />
              </div>
              <input
                type="number"
                value={stopLossPips}
                onChange={(e) => {
                  setStopLossPips(e.target.value);
                  setIsCalculated(false);
                }}
                placeholder="50"
                min="0"
                className="w-full bg-input border border-border rounded-xl pl-12 pr-4 py-3 text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
              />
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-3 mt-8">
          <button
            onClick={handleCalculate}
            className="flex-1 bg-primary text-primary-foreground font-semibold py-3.5 px-6 rounded-xl hover:opacity-90 transition-all active:scale-[0.98] focus:outline-none focus:ring-2 focus:ring-primary/50"
          >
            Calculate
          </button>
          <button
            onClick={handleReset}
            className="px-6 py-3.5 bg-secondary text-secondary-foreground font-medium rounded-xl hover:bg-secondary/80 transition-all focus:outline-none focus:ring-2 focus:ring-border"
          >
            Reset
          </button>
        </div>

        {/* Result */}
        {isCalculated && result.isValid && (
          <div className="mt-8 p-6 bg-primary/5 border border-primary/20 rounded-xl animate-in fade-in slide-in-from-bottom-4 duration-300">
            <div className="text-center">
              <p className="text-sm text-muted-foreground mb-1">
                Recommended Lot Size
              </p>
              <p className="text-4xl md:text-5xl font-bold text-primary">
                {result.lotSize.toFixed(2)}
              </p>
              <p className="text-sm text-muted-foreground mt-2">
                Standard Lots
              </p>
            </div>

            <div className="mt-6 pt-6 border-t border-border/50 grid grid-cols-2 gap-4">
              <div className="text-center">
                <p className="text-xs text-muted-foreground mb-1">Risk Amount</p>
                <p className="text-lg font-semibold text-foreground">
                  ${result.riskAmount.toLocaleString()}
                </p>
              </div>
              <div className="text-center">
                <p className="text-xs text-muted-foreground mb-1">Pip Value</p>
                <p className="text-lg font-semibold text-foreground">
                  ${selectedPair.pipValue}/pip
                </p>
              </div>
            </div>
          </div>
        )}

        {isCalculated && !result.isValid && (
          <div className="mt-8 p-4 bg-destructive/10 border border-destructive/20 rounded-xl text-center">
            <p className="text-destructive text-sm">
              Please enter valid positive values for all fields
            </p>
          </div>
        )}
      </div>

      {/* Formula Info */}
      <div className="mt-6 p-4 bg-card/50 border border-border/50 rounded-xl">
        <p className="text-xs text-muted-foreground text-center">
          <span className="font-medium">Formula:</span> Lot Size = (Account Balance × Risk %) ÷ (Stop Loss Pips × Pip Value)
        </p>
      </div>
    </div>
  );
}
